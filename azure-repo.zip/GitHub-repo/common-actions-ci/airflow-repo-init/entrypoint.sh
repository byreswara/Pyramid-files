#!/bin/bash

# Disable certificate warnings
export CURL_SSL_BACKEND="openssl"

# Artifactory credentials from environment variables
RT_USER=${RT_USER}
RT_PASS=${RT_PASS}
RT_API_URL=${RT_API_URL}

# Check if Artifactory credentials are set
function check_credentials() {
  if [[ -z "$RT_USER" || -z "$RT_PASS" || -z "$RT_API_URL" ]]; then
    echo "Error: Artifactory credentials or API URL not set"
    exit 1
  fi
}

# Function to create JSON payload
function create_json_payload() {
  local REPO=$1
  local RCLASS=$2
  local REPOSITORIES=$3

  local DESC="Repository created via GitHub Action for airflow"
  local TYPE="rpm"
  local LAYOUT="simple-default"
  local ENABLE_FILE_LISTS_INDEXING="true"
  local CALCULATE_YUM_METADATA="true"
  local SNAPSHOT_VERSION_BEHAVIOR="non-unique"  # Options: unique, non-unique, deployer

  # Construct JSON
  JSON_PAYLOAD=$(cat <<EOF
{
  "key": "$REPO",
  "description": "$DESC",
  "packageType": "$TYPE",
  "rclass": "$RCLASS",
  "repoLayoutRef": "$LAYOUT",
  "enableFileListsIndexing": $ENABLE_FILE_LISTS_INDEXING,
  "calculateYumMetadata": $CALCULATE_YUM_METADATA,
  "snapshotVersionBehavior": "$SNAPSHOT_VERSION_BEHAVIOR"
EOF
)

  if [[ -n "$REPOSITORIES" ]]; then
    JSON_PAYLOAD+=", \"repositories\": $REPOSITORIES"
  fi

  JSON_PAYLOAD+="}"

  echo "$JSON_PAYLOAD"
}

# Function to create repository in Artifactory
function create_repo() {
  local REPO=$1
  local JSON_PAYLOAD=$2

  # Make the API call to create the repository
  RESPONSE=$(curl -s -u "$RT_USER:$RT_PASS" -X PUT "$RT_API_URL/api/repositories/$REPO" \
    -H "Content-Type: application/json" \
    --data "$JSON_PAYLOAD" \
    --insecure)

  echo "Response from Artifactory:"
  echo "$RESPONSE"
}

# Function to create a local repository
function create_local_repo() {
  local REPO="${BRANCH_NAME}-yum"
  echo "Creating local repository: $REPO"

  # Create JSON payload for local repository
  JSON_PAYLOAD=$(create_json_payload "$REPO" "local")
  
  # Create the repository
  create_repo "$REPO" "$JSON_PAYLOAD"
}

# Function to create a virtual repository
function create_virtual_repo() {
  local REPO="${BRANCH_NAME}-virt"
  local REPOSITORIES="[\"${BRANCH_NAME}-local\", \"libs-snapshot-local\"]"

  echo "Creating virtual repository: $REPO"

  # Create JSON payload for virtual repository
  JSON_PAYLOAD=$(create_json_payload "$REPO" "virtual" "$REPOSITORIES")
  
  # Create the repository
  create_repo "$REPO" "$JSON_PAYLOAD"
}

# Main execution
function main() {
  check_credentials
  create_local_repo
  #create_virtual_repo
}

main
