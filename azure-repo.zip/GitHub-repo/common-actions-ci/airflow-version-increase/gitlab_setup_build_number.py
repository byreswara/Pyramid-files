#!/usr/bin/env python3
import argparse

import urllib3
import sys

urllib3.disable_warnings()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-num", "--build_number", help="Build number to insert", required=True)
    parser.add_argument("-v", "--version", help="Version to insert", required=True)
    parser.add_argument("-f", "--file", help="path to __init__.py file to write", required=True)

    args = parser.parse_args()

    try:
        with open(args.file, "a") as file_object:
            file_object.write("__version__ = '%s'\n__buildnumber__ = '%s'\n" % (args.version, args.build_number))
            print("write build number to file success")
    except IOError:
        print("write build number to file fail")


if __name__ == "__main__":
    sys.exit(main())
