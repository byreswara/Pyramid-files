#!/usr/bin/env python3
import itertools
import json
import requests
import urllib3
import sys
import re
import argparse
import os
import numpy as np
from packaging import version

urllib3.disable_warnings()

version_re = re.compile("\d+\.\d+\.\d+")
version_to_var_re = lambda ver: (re.match("(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)", ver)).groupdict()
stringToIntArr = lambda ver: list(map(int, ver.split(".")))
strToBoolean = lambda str1: str1.lower() == 'true'

def promote(ver: str, major: bool, minor: bool, patch: bool):
    version = version_to_var_re(ver)
    if major:
        version["minor"] = 1
        version["patch"] = 0
    if minor:
        version["patch"] = 0
    return "%d.%d.%d" % (
        int(version["major"]) + int(major),
        int(version["minor"]) + int(minor),
        int(version["patch"]) + int(patch)
    )

def comperator(ver1, ver2):
    if ver2[0] > ver1[0]:
        return True
    elif ver2[1] > ver1[1]:
        return True
    elif ver2[2] > ver1[2]:
        return True
    return False

def getMaxVersion(ver1: str, ver2: str):
    try:
        return ver2 if version.parse(ver2) > version.parse(ver1) else ver1
    except Exception as e:
        print(f"Error comparing versions: {ver1}, {ver2}: {e}")
        return ver1

def responeToList(response):
    print("Response Code:", response.status_code)
    if response.status_code != 200:
        print("Non-200 response received. Returning default [0.0.0]")
        return ["0.0.0"]
    try:
        data = json.loads(response.text)
        file_list = data.get("files", [])
        print(f"Files found: {file_list[:3]} (showing max 3)")
        return list(itertools.chain.from_iterable(
            list(map(lambda fileName: (version_re.findall(fileName)), file_list))))
    except Exception as e:
        print(f"Failed to parse response: {e}")
        return ["0.0.0"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-p", "--projectName", help="Project name. e.g., MLP-SERVICE", required=True)
    parser.add_argument("-major", "--major", help="Promote major digit", required=False, default="False")
    parser.add_argument("-minor", "--minor", help="Promote minor digit", required=False, default="False")
    parser.add_argument("-patch", "--patch", help="Promote patch digit", required=False, default="False")
    parser.add_argument("-r", "--repo", help="Repository name", required=True)

    args = parser.parse_args()

    headers = None
    rt_user = os.environ.get('RT_USER')
    rt_pass = os.environ.get('RT_PASS')
    rt_url = os.environ.get('RT_API_URL')
    branch = os.environ.get('CI_COMMIT_REF_NAME', "Not set")

    print(f"[INFO] Project: {args.projectName}")
    print(f"[INFO] Repo: {args.repo}")
    print(f"[INFO] Branch: {branch}")
    print(f"[INFO] RT_API_URL: {rt_url}")
    print(f"[INFO] RT_USER: {'Set' if rt_user else 'Not set'}")
    print(f"[INFO] RT_PASS: {'Set' if rt_pass else 'Not set'}")

    if not rt_url:
        print("Error: RT_API_URL environment variable is not set.")
        sys.exit(1)

    auth = (rt_user and rt_pass) and requests.auth.HTTPBasicAuth(rt_user, rt_pass) or None

    feature_url = f'{rt_url}/search/pattern?pattern={args.repo}:*{args.projectName}*-*.rpm'
    print(f"[INFO] Fetching feature repo artifacts: {feature_url}")
    response = requests.get(feature_url, headers=headers, verify=False, auth=auth)
    candidate_artifact: list = responeToList(response)

    yum_url = f'{rt_url}/search/pattern?pattern=yum-local:*{args.projectName}*-*.rpm'
    print(f"[INFO] Fetching yum-local artifacts: {yum_url}")
    response = requests.get(yum_url, headers=headers, verify=False, auth=auth)
    candidate_artifact += responeToList(response)

    print(f"[INFO] Candidate versions found: {candidate_artifact}")

    max_candidate = "0.0.0"
    version_branch_pattern = re.compile("^v\d+\.\d+\.\d+")
    if version_branch_pattern.match(branch):
        print(f"[INFO] Using branch version: {branch}")
        max_candidate = branch[1:]
    else:
        for artifact in candidate_artifact:
            max_candidate = getMaxVersion(max_candidate, artifact)

    print(f"[INFO] Max candidate version: {max_candidate}")

    new_version = promote(max_candidate,
                          strToBoolean(args.major),
                          strToBoolean(args.minor),
                          strToBoolean(args.patch))

    print(f"[RESULT] Promoted version: {new_version}")
    print(new_version)

if __name__ == "__main__":
    sys.exit(main())
