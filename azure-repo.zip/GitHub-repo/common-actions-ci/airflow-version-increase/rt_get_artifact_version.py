#!/usr/bin/env python3
import json

import requests
import urllib3
import sys
import re
import argparse
import os

urllib3.disable_warnings()

version_re = re.compile("\d+\.\d+\.\d+-\d+")
build_number_re = re.compile("-\d+")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", help="Artifact release version", required=True)
    parser.add_argument("-p", "--projectName", help="project name. for example :MLP-SERVICE", required=True)
    parser.add_argument("-r", "--repo", help="Repository", required=True)

    args = parser.parse_args()

    headers = None

    rt_user = os.environ.get('RT_USER')
    rt_pass = os.environ.get('RT_PASS')
    rt_url = os.environ['RT_API_URL']
    auth = (rt_user != None) and requests.auth.HTTPBasicAuth(rt_user, rt_pass) or None

    response = requests.get(
        '%s/search/pattern?pattern=%s:*%s*%s-*.rpm' % (
            os.environ['RT_API_URL'],
            args.repo,
            args.projectName,
            args.version
        )
        , headers=headers, verify=False, auth=auth)

    if response.status_code != 200:
        print(0)
    else:
        candidate_artifact = (json.loads(response.text))["files"]
        max_candidate = 0
        for name in candidate_artifact:
            try:
                candidate_str = (build_number_re.findall(version_re.findall(name)[0])[0])
            # if not find any match in candidate_artifact continue to the next candidate_artifact
            except IndexError:
                continue
            candidate = int(candidate_str[1:])
            if candidate > max_candidate:
                max_candidate = candidate
        max_candidate += 1
        print(max_candidate)


if __name__ == "__main__":
    sys.exit(main())
