echo $GITHUB_WORKSPACE
cd $GITHUB_WORKSPACE
echo "###############################################################################"
echo "# Environment variables"
echo "###############################################################################"
env
echo "###############################################################################"
echo "# Configure timezone"
echo "###############################################################################"
rm -rf /etc/localtime
ln -s /usr/share/zoneinfo/Israel /etc/localtime
echo "###############################################################################"
echo "Install jfrog CLI"
echo "###############################################################################"
curl -V
env -u HTTP_PROXY -u HTTPS_PROXY -u http_proxy -u https_proxy curl -k -fL https://getcli.jfrog.io | sh

echo "###############################################################################"
$JFROG_CMD config hzlab --interactive=false --url=$RT_API_URL --user=$RT_USER --password=$RT_PASS
$JFROG_CMD ping --server-id=hzlab
echo "# Execution ..."
echo $RT_API_URL
echo $RT_USER
DEPLOY_REPO="yum-local"
if [[ "$BRANCH_NAME" =~ ^v[0-9]+\.[0-9]+\.[0-9]+$ || "$BRANCH_NAME" = "master" || "$BRANCH_NAME" = "main"  ]]; then
  echo "Use defaults repo"
else
  DEPLOY_REPO=$BRANCH_NAME-yum
fi
export DEPLOYED_REPO_URL="$RT_API_URL/$DEPLOY_REPO"
echo "DEPLOYED_REPO_URL=$DEPLOYED_REPO_URL" >> $GITHUB_ENV
echo "DEPLOY_REPO=$DEPLOY_REPO" >> $GITHUB_ENV

