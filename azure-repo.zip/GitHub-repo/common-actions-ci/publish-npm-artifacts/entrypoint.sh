#!/bin/bash
set -e
cd ${GITHUB_WORKSPACE}

npm config set registry http://repo1.outseer.net:8081/artifactory/api/npm
curl -u ${USER_NAME}:${PASSWORD} http://repo1.outseer.net:8081/artifactory/api/npm/auth > ~/.npmrc
npm config fix
npm publish --registry=http://repo1.outseer.net:8081/artifactory/api/npm/libs-npm-local