#!/bin/bash
set -e

STORAGE_ACCOUNT_NAME=${StorageAccountName}
CONTAINER_NAME=static

echo "Publishing to $STORAGE_ACCOUNT_NAME/$CONTAINER_NAME"

FILE_PATH=${FilePath}
BLOB_NAME=$(basename $FilePath)
SAS_TOKEN=${StorageAccountSasKey}
cd ${GITHUB_WORKSPACE}
DATE=$(date +"%Y-%m-%d-%H-%M-%S")

ls -ltsa
exists=$(az storage blob exists \
  --account-name "$STORAGE_ACCOUNT_NAME" \
  --container-name "$CONTAINER_NAME" \
  --name "$BLOB_NAME" \
  --sas-token "$SAS_TOKEN" \
  --query "exists" \
  --output tsv)

if [ "$exists" == "true" ]; then
  echo "Rename blob $STORAGE_ACCOUNT_NAME $CONTAINER_NAME/$BLOB_NAME to $CONTAINER_NAME ${DATE}_${BLOB_NAME}."
  az storage blob copy start \
    --account-name "$STORAGE_ACCOUNT_NAME" \
    --destination-container "$CONTAINER_NAME" \
    --destination-blob "${DATE}_${BLOB_NAME}" \
    --source-blob "${BLOB_NAME}" \
    --source-container "$CONTAINER_NAME" \
    --sas-token "$SAS_TOKEN"
fi

echo "Uploading blob  $STORAGE_ACCOUNT_NAME $CONTAINER_NAME/$BLOB_NAME."
az storage blob upload \
  --account-name "$STORAGE_ACCOUNT_NAME" \
  --container-name "$CONTAINER_NAME" \
  --name "$BLOB_NAME" \
  --file "$FILE_PATH" \
  --sas-token "$SAS_TOKEN" \
  --overwrite true \
  --verbose

echo "File uploaded successfully to $CONTAINER_NAME in $STORAGE_ACCOUNT_NAME."
