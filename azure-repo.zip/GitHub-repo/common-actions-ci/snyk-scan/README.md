# Snyk Scan Action

- This action runs a Snyk scan on checked out code
- This is compose based github actions 


## Inputs

- `SNYK_TOKEN`: Snyk authentication token (required)
- `MVN_SETTINGS_FILE_Path`: Maven setting file. default path is '/root/.m2/settings.xml'
- `EXCLUDE_DIRECTORY`: exclude specific directory

## Example Usage

name: Snyk Scan poc
on:
  workflow_dispatch:

jobs:
  build:  
    runs-on: fmoc-docker
    environment: test
    steps:
    - uses: actions/checkout@v4

    - name: snyk scan
      uses: devops-outseer/common-actions/snyk-scan@main
      with:
        SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}

## F&Q
How to chnage default MAVEN SETTINGS File?

if it is in different job please assign the variable to a output
```

      - name: Run Snyk Scan
        uses: devops-outseer/common-actions/snyk-scan@data-outseer
        with:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
          MVN_SETTINGS_FILE_Path: '/opt/settings.xml'
```
       

