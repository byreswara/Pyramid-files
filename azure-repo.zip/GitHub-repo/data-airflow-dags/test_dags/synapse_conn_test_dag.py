from airflow import DAG
from airflow.providers.microsoft.azure.hooks.synapse import AzureSynapseHook
from airflow.operators.python import PythonOperator
from datetime import datetime

def test_synapse_conn(**context):
    hook = AzureSynapseHook(azure_synapse_conn_id='dev-synapse')
    # Try to get workspace details, list pipelines, etc.
    pipelines = hook.get_pipelines()
    print(f"Found {len(pipelines)} pipelines.")

with DAG('test_synapse_conn_dag', start_date=datetime(2024,1,1), schedule=None, catchup=False) as dag:
    t1 = PythonOperator(
        task_id='test_synapse_conn',
        python_callable=test_synapse_conn
    )