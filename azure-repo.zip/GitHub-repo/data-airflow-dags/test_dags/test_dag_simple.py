from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime

with DAG(
    'test_hello',
    start_date=datetime(2023, 1, 1),
    schedule=None,  # <-- new parameter name
    catchup=False,
) as dag:
    t1 = EmptyOperator(task_id='hello')
