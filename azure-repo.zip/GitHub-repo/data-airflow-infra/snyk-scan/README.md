# Snyk Scan Action

- This action runs a Snyk scan
- This is compose based github actions 


## Inputs

- `SNYK_TOKEN`: Snyk authentication token (required)
- `IMAGE_NAME`: Docker image name which snyk needs to scan
- `VULNERABILITY_SEVERITY`: vulnerability severity Ex: high or critical

## Example Usage

name: Snyk Scan
on:
  workflow_dispatch:
    inputs:
      ImageName:
        description: "Enter Image Name. Ex: apache/airflow:3.0.3"
        required: true
      VulnerabilitySeverity:
        description: "Enter Severity . Ex: high"
        default: critical
        required: true

jobs:
  snyk_scan:  
    runs-on: bb-runners
    steps:
     - name: Run Snyk Scan
      uses: Data-outseer/data-airflow-infra/snyk-scan@main
      with:
        SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        IMAGE_NAME: ${{github.event.inputs.ImageName}}
        VULNERABILITY_SEVERITY: ${{github.event.inputs.VulnerabilitySeverity}}
       

