# Manual cross account activity not available in bicep! (TF could probably do it...)
- The data common dns zone for privatelink.sql.azuresynapse.net should be added to the vnet
- The vnet needs to be peered with the appropriate vnet corresponding to the target GDW(s)

# Manual config of the VNet Data Gateway
- https://learn.microsoft.com/en-us/data-integration/vnet/create-data-gateways
- Note - you need to *explicitly* have contributor access on the actual vnet to do this
- The VNet Data gateway includes a nice troubleshooting tool for DNS/connectivity

# Power BI
- Publish report and semantic model from powerbi desktop
- Do not mix private data sources (excel files) with this
- Go to settings on the semantic model and ensure the gateway connection is selected - additional creds should not be required