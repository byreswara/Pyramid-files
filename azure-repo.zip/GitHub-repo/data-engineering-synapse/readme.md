# Git structure
- Feature/bugfix -> colab -> multiple publish branch
- each Synapse env will monitor the appropriate live folder in their publish branch
    - We use different publish branches only to allow us to do a phased rollout (content between same version on different branches is identical)

# Tests
- Need docker running - install Rancher
- If the docker container doesn't start ensure unix-style line endings (LF) are present in entrypoint.sh and configure-db.sh. Git keeps removing them...
- Should install ODBC Driver for SQL Server

# Creating a T2/T3 pipeline
Here is a step-by-step instruction on how we create synapse pipelines:
- Draft a pipeline (and other objects you might need, like data sources or triggers) in Azure Synapse UI.
- Take the pipeline JSON representation, along with the other objects, save it to a jinja template in the templates folder
(you might be able to reuse some templates, triggers for example), and parametrize them. In particular, queries that the pipeline uses should be parameters, placed in templates/queries.
- Update the render.py to render your templates. These will apprear in the rendered folder, and, unless you are using the `--dry-run` option, also in the live folder. 
The live folder is what Azure Synapse reads, so whatever is there is in Synapse. You can render a specific environment by passing the env name as an argument, for example, `python3 render.py dev`.
- Write unit tests for your pipeline in the tests folder. This involves:
  - Defining your input/output tables in config/ddl. These tables will get created during the test run.
  - Defining the input/output data in data folder. This data will get inserted into the tables.
  - Update sql_test.py with unit tests for your data transformation. These use the given-when-then way to write test cases - 
  each test is given the expected output, and when it executes the corresponding queries against the input data, then we assert that output from running the queries matches the expected.
- With all of this done, after rendering and pushing your changes, you should see your pipeline in Azure Synapse. Check that it works there (in dev) and delete the old one 
(that you wrote in the UI, without templating) if it's still there.
- If the pipeline looks like it's working correctly, issue a pull request for your changes and have it approved. You should then see your new pipeline in the colab branch.
- In Synapse UI, dev, click on publish to publish your work to publish/dev branch (check that you are only publishing what you expect to). 
Your pipeline should now trigger automatically. Again check that it works.
- Then you are ready to deploy to other environments. Publish your rendered pipelines and other objects to uat, eu-prod, and us-prod.
After each publish, wait at least a day and see it the pipeline runs as intended.
- And you're done! Although, if you want to create some database objects, like views for example, you will need to write scripts for that 
in https://gitlab.com/gitlab-fri/data-science/data-engineering/data-warehouse-scripts and migrate them using the python migrator script.

# TODO
 - Add some tests (unit/e2e with test config)
 - Update the pipeline to commit the rendered updates back on hitting colab only