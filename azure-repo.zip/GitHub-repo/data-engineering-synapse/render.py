from jinja2 import Environment, FileSystemLoader
import shutil
import yaml
import os
import glob
import logging
import argparse
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('renderer')
environment = Environment(loader=FileSystemLoader("templates/"))
sequential_runtime_name = 'LocalSequentialRuntime'
storage_service_name = 'LocalLakeStorage'


def get_connection_name(server, user):
    safe_domain = server.split('-pl')[0]
    return "{}-{}".format(safe_domain, user).replace('_', '-').replace('.', '-')


''' return stacks preceeded by underscore, or empty list '''


def get_stacks(conf):
    return ['_a', '_b'] if conf['env'] == 'prod-eastus' else ['']


def get_pipeline_name(data_source):
    if data_source == "fmc":
        return 'FMC_DB'
    if data_source == "fmc_pm":
        return 'FMC_PM_TABLES'
    if data_source == "t2_fmc":
        return 'T2_APP_EVENT_LOG'
    if data_source == 'spark_evt':
        return 'UPDATE_EVENT_LOG_SPARK'
    elif data_source == 't3_fmc':
        return 'T3_FMC_ANALYTICS'
    elif data_source == 't3_evt':
        return "UPDATE_EVENT_LOG"
    elif data_source == 'metrics':
        return 'FMC_METRICS'
    else:
        return "FMOP_SFTP"


def render(template_path, render_file_name, dest, kwargs):
    template = environment.get_template(template_path)
    output = template.render(name=render_file_name, **kwargs)
    with (open(os.path.join(dest, render_file_name + '.json'), 'w')) as f:
        f.write(output)


def render_runtime(root, conf):
    dest = os.path.join(root, 'integrationRuntime')
    os.makedirs(dest, exist_ok=True)
    kwargs = {"location": conf['location'], "copyDataIntegrationUnits": 4}
    # default
    render("integrationRuntime/runtime.jinja", sequential_runtime_name, dest, kwargs)
    # second IR for FMC ETL in multi-stack env
    # note underscores are NOT allows in runtime names...
    if len(get_stacks(conf)) == 2:
        render("integrationRuntime/runtime.jinja", sequential_runtime_name + '-b', dest, kwargs)


def render_linked_services(root, conf):
    # render linked services
    dest = os.path.join(root, 'linkedService')
    os.makedirs(dest, exist_ok=True)

    stacks = get_stacks(conf)
    synapse_server = conf['synapse']['serverless']
    user = conf['sql_server']['user']
    secret_name = conf['sql_server']['cred']
    online_user = conf['fmc_online_db']['user']
    online_secret_name = conf['fmc_online_db']['cred']
    storage_account = conf['storage']['storage_account']
    secret_service = conf['key_vault']['service']
    sftp_service_name = conf['sftp_server']['service_name']
    secret_user_name = conf['sftp_server']['user_secret']
    secret_password_name = conf['sftp_server']['password_secret']
    sftp_host_secret = conf['sftp_server']['host_secret']
    runtime = sequential_runtime_name

    kwargs = {"synapse_server": synapse_server, "user": user, "secret_name": secret_name,
              "online_user": online_user, "online_secret_name": online_secret_name,
              "storage_account": storage_account, "secret_service": secret_service,
              "sftp_service_name": sftp_service_name,
              "secret_user_name": secret_user_name, "secret_password_name": secret_password_name,
              "sftp_host_secret": sftp_host_secret, "runtime": runtime}

    logger.debug('\n\nConnections\n\n')

    # data lake storage
    render("linkedService/data_lake.jinja", storage_service_name, dest, kwargs)
    if len(stacks) == 2:
        updated = dict(kwargs)
        updated['runtime'] = sequential_runtime_name + '-b'
        render("linkedService/data_lake.jinja", storage_service_name + '_b', dest, updated)

    # synapse
    render("linkedService/synapse.jinja", "LocalSynapseServerless", dest, kwargs)

    # vault
    render("linkedService/vault.jinja", secret_service, dest, kwargs)

    # sftp_server
    render("linkedService/sftp_server.jinja", sftp_service_name, dest, kwargs)

    # now rds services
    # note t1 fmc us needs two fmc pipelines....
    # function might mutate kwards
    for stack in stacks:
        if stack == '_b':
            kwargs['runtime'] = sequential_runtime_name + '-b'
        render_fmc_sql_server_linked_service(
            conf,
            dest,
            kwargs,
            stack,
            conf_key='sql_server',
            template_path="linkedService/sql_server.jinja"
        )
        render_fmc_sql_server_linked_service(
            conf,
            dest,
            kwargs,
            stack,
            conf_key='fmc_online_db',
            template_path="linkedService/fmc_online_db.jinja"
        )


def render_fmc_sql_server_linked_service(conf, dest, kwargs, stack, conf_key, template_path):
    connection_name = get_connection_name(conf[conf_key]['server' + stack], conf[conf_key]['user'])
    server = conf[conf_key]['server' + stack]
    kwargs["server"] = server
    logger.debug('Writing {}'.format(connection_name))
    render(template_path, connection_name, dest, kwargs)

def render_data_sinks(root, conf):
    # render data sinks
    dest = os.path.join(root, 'dataset')
    os.makedirs(dest, exist_ok=True)

    fmop_container_name = conf['storage']['fmop_container']

    kwargs = {"fmop_container_name": fmop_container_name,
              "storage_service": storage_service_name}

    logger.debug('\n\nData Sinks\n\n')

    # Parquet output sink renders
    for name, template in [('Parquet', "dataset/parquet.jinja"),
                           ('ParquetUnpartitioned', "dataset/parquet_unpartitioned.jinja")]:
        logger.debug('Writing {}'.format(name))
        render(template, name, dest, kwargs)
        if len(get_stacks(conf)) == 2:
            updated = dict(kwargs)
            updated['storage_service'] = storage_service_name + '_b'
            render(template, name + '_b', dest, updated)

    # Binary output sink render with decompression
    name = 'Unzipped_Dataset'
    logger.debug('Writing {}'.format(name))
    render("dataset/unzipped.jinja", name, dest, kwargs)

def render_sparkjobs(root, conf):
    # render spark jobs
    dest = os.path.join(root, 'sparkJobDefinition')
    os.makedirs(dest, exist_ok=True)

    logger.debug('\n\nSpark jobs\n\n')

    t2_app_event_log_kwargs = {
        "job_name": conf['spark']['t2_app_event_log']['job_name'],
        "spark_pool": conf['spark']['t2_app_event_log']['spark_pool'],
        "script_name": conf['spark']['t2_app_event_log']['script_name'],
        "executors_min": conf['spark']['t2_app_event_log']['executors_min'],
        "executors_max": conf['spark']['t2_app_event_log']['executors_max'],
    }
    t2_event_log_update_kwargs = {
        "job_name": conf['spark']['t2_event_log']['job_name'],
        "spark_pool": conf['spark']['t2_event_log']['spark_pool'],
        "script_name": conf['spark']['t2_event_log']['script_name'],
        "executors_min": conf['spark']['t2_event_log']['executors_min'],
        "executors_max": conf['spark']['t2_event_log']['executors_max'],
    }
    t3_gdn_fmc_contribution_kwargs = {
        "job_name": conf['spark']['t3_fmc_gdn_contribution']['job_name'],
        "spark_pool": conf['spark']['t3_fmc_gdn_contribution']['spark_pool'],
        "script_name": conf['spark']['t3_fmc_gdn_contribution']['script_name'],
        "executors_min": conf['spark']['t3_fmc_gdn_contribution']['executors_min'],
        "executors_max": conf['spark']['t3_fmc_gdn_contribution']['executors_max'],
    }
    t3_gdn_fmc_shared_entities_contribution_kwargs = {
        "job_name": conf['spark']['t3_fmc_gdn_shared_entities']['job_name'],
        "spark_pool": conf['spark']['t3_fmc_gdn_shared_entities']['spark_pool'],
        "script_name": conf['spark']['t3_fmc_gdn_shared_entities']['script_name'],
        "executors_min": conf['spark']['t3_fmc_gdn_shared_entities']['executors_min'],
        "executors_max": conf['spark']['t3_fmc_gdn_shared_entities']['executors_max'],
    }

    path = "sparkJobDefinition/spark_job.jinja"

    for name, kwargs in zip(
        ['APP_EVENT_LOG_UPDATED', 'EVENT_LOG_UPDATED', 'FMC_GDN_CONTRIBUTION', 'FMC_GDN_SHARED_ENTITIES'],
        [t2_app_event_log_kwargs, t2_event_log_update_kwargs, t3_gdn_fmc_contribution_kwargs, t3_gdn_fmc_shared_entities_contribution_kwargs]
    ):
        logger.debug('Writing {}'.format(name))
        render(path, name, dest, kwargs | {"storage_account": conf['storage']['storage_account']},
)

def render_data_sources(root, conf):
    # render data sources
    dest = os.path.join(root, 'dataset')
    os.makedirs(dest, exist_ok=True)
    sql_conf = conf['sql_server']
    sftp_service = conf['sftp_server']['service_name']

    logger.debug('\n\nData Sources\n\n')


    render_sql_server_data_sources(conf=conf, conf_key='sql_server', dest=dest, name_prefix='SQL_Server_Database',
                                   template_path="dataset/sql_server_table.jinja")
    render_sql_server_data_sources(conf=conf, conf_key='fmc_online_db', dest=dest, name_prefix='FMC_Online_db',
                                   template_path="dataset/fmc_online_db.jinja")

    name = 'LocalSynapse'
    logger.debug('Writing {}'.format(name))
    render("dataset/synapse_table.jinja", name, dest, {"linked_service": "LocalSynapseServerless"})

    name = 'SFTP_Dataset'
    logger.debug('Writing {}'.format(name))
    render("dataset/sftp_zip.jinja", name, dest, {"linked_service": sftp_service})


def render_sql_server_data_sources(conf, conf_key, dest, name_prefix, template_path):
    for stack in get_stacks(conf):
        name = name_prefix + stack
        logger.debug('Writing {}'.format(name))
        connection_name = get_connection_name(conf[conf_key]['server' + stack], conf[conf_key]['user'])
        render(template_path, name, dest, {"linked_service": connection_name})


def render_pipelines(root, conf):
    logger.debug('\n\nPipelines\n\n')

    dest = os.path.join(root, 'pipeline')
    os.makedirs(dest, exist_ok=True)

    queries = dict()
    for table in glob.glob("templates/queries/*.txt"):
        name = os.path.basename(table).split('.txt')[0]
        with open(table) as f:
            queries[name] = ''.join(f.readlines()).replace('\n', '\\n')

    kwargs = {"concurrency": 1,
              "parquet_dataset": "Parquet",
              "container": 't1-fmc',
              "retry": conf["retry"],
              "retryIntervalInSeconds": conf["retryIntervalInSeconds"],
              "event_log_stored_proc": queries['event_log'],
              "event_log_update_stored_proc": queries['event_log_update'],
              "event_feedback_query": queries['event_feedback'],
              "app_event_log_query": queries['app_event_log'],
              "app_event_update_query": queries['app_event_update'],
              "billing_transaction_query": queries['billing_transaction'],
              "dm_audit_query": queries['dm_audit'],
              "rba_bs_buckets_query": queries['rba_bs_buckets'],
              "rba_bs_buckets_silent_query": queries['rba_bs_buckets_silent'],
              "rba_bs_buckets_static_query": queries['rba_bs_buckets_static'],
              "t3_transaction_report": queries['t3_transaction_report'],
              "scores_query": queries['model_scores'],
              "precisions_and_recalls_query": queries['precisions_and_recalls'],
              "metrics_query": queries['model_metrics'],
              "pm_rule_query": queries['pm_rule'],
              "pm_condition": queries['pm_condition'],
              "pm_expression": queries['pm_expression'],
              "pm_policy": queries['pm_policy'],
              "pm_policy_list": queries['pm_policy_list'],
              "pm_rule_channel_indicators": queries['pm_rule_channel_indicators'],
              "pm_rule_event_types": queries['pm_rule_event_types'],
              "pm_create_case_for_action": queries['pm_create_case_for_action'],
              "storage_account": conf['storage']['storage_account']
              }

    # t1
    # note t1 fmc us needs two fmc pipelines....
    for stack in get_stacks(conf):
        updated = dict(kwargs)
        updated['sql_server_db'] = 'SQL_Server_Database' + stack
        updated['fmc_online_db'] = 'FMC_Online_db' + stack
        if stack == '_b':
            updated['parquet_dataset'] = 'Parquet_b'
        render("pipeline/fmc_sql.jinja", get_pipeline_name("fmc") + stack.upper(), dest, updated)
        render("pipeline/fmc_pm_tables.jinja", get_pipeline_name("fmc_pm") + stack.upper(), dest, updated)
    render("pipeline/fmop_sftp.jinja", get_pipeline_name("fmop"), dest, kwargs)

    # t2
    render("pipeline/fmc_t2_app_event_log.jinja", get_pipeline_name("t2_fmc"), dest, kwargs)
    render("pipeline/update_event_log_spark.jinja", get_pipeline_name("spark_evt"), dest, kwargs)

    # t3
    render("pipeline/t3_fmc_analytics.jinja", get_pipeline_name("t3_fmc"), dest, kwargs)
    render("pipeline/update_event_log.jinja", get_pipeline_name("t3_evt"), dest, kwargs)
    render("pipeline/fmc_metrics.jinja", get_pipeline_name("metrics"), dest, kwargs)


# TODO use render() function
def render_triggers(root, conf):
    logger.debug('\n\nTriggers\n\n')

    dest = os.path.join(root, 'trigger')
    os.makedirs(dest, exist_ok=True)
    template = environment.get_template("trigger/trigger.jinja")

    # fmc t1 trigger
    now = '2024-01-01'  # old: datetime.today().strftime('%Y-%m-%d') - do not use as it creates meaningless deltas on renders!
    stacks = get_stacks(conf)
    pipeline_name_key = "fmc"
    for pipeline_name_key in ['fmc','fmc_pm']:
        stack = render_trigger_per_tenant(conf, dest, now, pipeline_name_key, stacks, template)

    # use single_tenant trigger for update_event_log_spark
    name = 'UPDATE_EVENT_LOG_SPARK'
    output = template.render(name=name, pipeline=name, tenant='*',
                    frequency='Hour', interval=24, start_time="{}T{}".format(now, conf['execution_time']['t2']))
    with (open(os.path.join(dest, name + '.json'), 'w')) as f:
                f.write(output)

    # fmc t3 analytics, event log update and metrics trigger
    tenant_config = 'tenants' if len(stack) == 0 else 'tenants_a'
    if conf[tenant_config] is not None:
        template = environment.get_template("trigger/multi_tenant_trigger.jinja")

        if len(stack) == 0:
            tenants = json.dumps(list(conf['tenants'].keys()))
        else:
            tenants_a = [] if conf['tenants_a'] is None else list(conf['tenants_a'].keys())
            tenants_b = [] if conf['tenants_b'] is None else list(conf['tenants_b'].keys())
            tenants = json.dumps(tenants_a + tenants_b)

        for name in ["T3_FMC_ANALYTICS", "UPDATE_EVENT_LOG", "FMC_METRICS"]:
            execution_time = conf['execution_time']['t2' if name == 'UPDATE_EVENT_LOG' else 't3']
            # Note that pipeline name happens to be the same as trigger name
            output = template.render(name=name, pipeline=name, tenants=tenants, frequency='Hour',
                                     interval=24, start_time="{}T{}".format(now, execution_time))
            with (open(os.path.join(dest, name + '.json'), 'w')) as f:
                f.write(output)

    template = environment.get_template("trigger/trigger_between_dates.jinja")
    for name in ["T2_APP_EVENT_LOG"]:
        execution_time = conf['execution_time']['t2' if name == "T2_APP_EVENT_LOG" else 't3']
        # Note that pipeline name happens to be the same as trigger name
        output = template.render(name=name, pipeline=name, frequency='Hour',
                                     interval=24, start_time="{}T{}".format(now, execution_time))
        with (open(os.path.join(dest, name + '.json'), 'w')) as f:
            f.write(output)


    # # fmop trigger
    # template = environment.get_template("trigger/trigger.jinja")
    # name = "FMOP_SFTP_TRIGGER"
    # execution_time = conf['sftp_server']['execution_time']
    # tenant = conf['sftp_server']['tenant']
    # # convention: trigger and pipeline have the same name
    # output = template.render(name=name, pipeline=get_pipeline_name("fmop"), tenant=tenant, frequency='Hour',
    #                          interval=24, start_time="{}T{}".format(now, execution_time))
    # with (open(os.path.join(dest, name + '.json'), 'w')) as f:
    #     f.write(output)


def render_trigger_per_tenant(conf, dest, now, pipeline_name_key, stacks, template):
    is_online_db: str = '_online' if 'pm' in pipeline_name_key else ''
    for stack in stacks:
        tenant_config = 'tenants' if len(stack) == 0 else 'tenants'+ is_online_db + stack
        if conf[tenant_config] is not None:
            for tenant in conf[tenant_config]:
                name = '{}_{}'.format(get_pipeline_name(pipeline_name_key), tenant.upper())
                execution_time = conf['execution_time']['t1']
                # convention: trigger and pipeline have the same name
                output = template.render(name=name, pipeline=get_pipeline_name(pipeline_name_key) + stack,
                                         tenant=tenant,
                                         frequency='Hour',
                                         interval=24, start_time="{}T{}".format(now, execution_time))
                with (open(os.path.join(dest, name + '.json'), 'w')) as f:
                    f.write(output)
    return stack


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Data Science Pipeline Renderer",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('env', default='all', nargs='?')
    parser.add_argument("--dry-run", action="store_true",
                        help="Do not apply renders")
    args = vars(parser.parse_args())

    # TODO make separate render process per pipeline
    # TODO make distinct vars folder for fmop
    # TODO if there is common - move to common
    # delete existing rendered files
    shutil.rmtree('rendered', ignore_errors=True)
    configs = glob.glob("values/fmc-pipeline/*.yaml") if args['env'] == 'all' else glob.glob(
        "values/fmc-pipeline/{}.yaml".format(args['env']))
    for c in configs:
        name = os.path.basename(c).split('.yaml')[0]
        logger.info("Rendering environment: %s", name)
        root = os.path.join('rendered', name)
        with open(c, "r") as f:
            conf = yaml.safe_load(f)
            conf['env'] = name
        render_runtime(root, conf)
        render_linked_services(root, conf)
        render_data_sinks(root, conf)
        render_data_sources(root, conf)
        render_pipelines(root, conf)
        render_triggers(root, conf)
        render_sparkjobs(root,conf)
        # now copy to main path
        if not args['dry_run']:
            logger.debug('Applying render %s', name)
            shutil.copytree(root, os.path.join('live', name), dirs_exist_ok=True)
        else:
            logger.info('Dry run - will render only')
