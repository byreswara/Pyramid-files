# Data Warehouse infra

This repo contains the bicep template to deploy a regional data warehouse to a target resource group. It contains the following resources:
- Storage account
- Key vault (for rds access secrets)
- Synapse workspace
- Private link connections to target private link services

Actual pipelines are managed via git in a separate repo.

## Requirements
- A *new* resource group and an Azure devops service connection attached to the pipeline
- A configured Azure devops variable group with the following variables:
    - **azureResourceManagerConnection**: The name of the service connection
    - **location**: The region
    - **resourceGroupName**: The target resource group
    - **synapseAdminGroupObjectId**: The AAD id of the group which should have admin access in synapse
- The application user provisoned by Azure gitops needs to have RBAC permissions added to it (this is currently manual!)
- New deployments should be in branches named "/release/myname", with a corresponding variable group *myname* and bicep parameter file *myname.json*

## Known issues
- The private link to FMC environments may fail if the synapse subscription id (which is not necessarily the same as the one beloning to the main resource group) is not on the whitelist. If this occurs - add it to the whitelist on the FMC side, then just delete the failed synapse private endpoint and recreate with the same name.
- Synapse connectivity is set to public by default, but with a firewall rule that blocks everything. An admin can add IPs to the firewall. Ultimately a private link setup will be used instead (via the VPN).
- Configuring synapse git integration is currently manual. Refer to the synapse data eng repo for instructions - ensure to follow naming and layout conventions