param(
  [Parameter(Mandatory=$true)]
  [string] $SynapseWorkspaceName,
  [Parameter(Mandatory=$true)]
  [string] $SynapseWorkspaceID,
  [Parameter(Mandatory=$true)]
  [string[]] $PrivateLinkIds,
  [Parameter(Mandatory=$true)]
  [string[]] $PrivateLinkNames,
  [Parameter(Mandatory=$true)]
  [string[]] $PrivateEndPointIds,
  [Parameter(Mandatory=$true)]
  [string[]] $PrivateEndPointNames,
  [Parameter(Mandatory=$true)]
  [string] $UAMIIdentityID
)

function Save-SynapseLinkedService {
  param (
      [string] $SynapseWorkspaceName,
      [string] $LinkedServiceName,
      [string] $LinkedServiceRequestBody
  )

  [string] $uri = "https://$SynapseWorkspaceName.dev.azuresynapse.net/linkedservices/$LinkedServiceName"
  $uri += "?api-version=2019-06-01-preview"

  Write-Host "Creating Linked Service [$LinkedServiceName]..."
  $retryCount = 1
  $completed = $false
  $secondsDelay = 60
  $retries = 10

  while (-not $completed) {
    try {
        Invoke-WebRequest -Method Put -ContentType "application/json" -Uri $uri -Headers $headers -Body $LinkedServiceRequestBody -ErrorAction Stop
        Write-Host "Linked service [$LinkedServiceName] created successfully."
        $completed = $true
    }
    catch {
      if ($retryCount -ge $retries) {
          Write-Host "Linked service [$LinkedServiceName] creation failed the maximum number of $retryCount times."
          Write-Warning $Error[0]
          throw
      }
      else {
          Write-Host "Linked service [$LinkedServiceName] creation failed $retryCount time(s). Retrying in $secondsDelay seconds."
          Write-Warning $Error[0]
          Start-Sleep $secondsDelay
          $retryCount++
      }
    }
  }
}

#------------------------------------------------------------------------------------------------------------
# CONTROL PLANE OPERATION: ASSIGN SYNAPSE WORKSPACE ADMINISTRATOR TO USER-ASSIGNED MANAGED IDENTITY
#------------------------------------------------------------------------------------------------------------

$token = (Get-AzAccessToken -Resource "https://dev.azuresynapse.net").Token
$headers = @{ Authorization = "Bearer $token" }

Write-Host "Assign Synapse Administrator Role to UAMI"

$roleId = "6e4bf58a-b8e1-4cc3-bbf9-d73143322b78"
$existingAssignment = Get-AzSynapseRoleAssignment -ObjectId $UAMIIdentityID -RoleDefinitionId $roleId -WorkspaceName $SynapseWorkspaceName -ErrorAction SilentlyContinue

if (-not $existingAssignment) {
  Write-Host "No existing role assignment found. Creating new role assignment..."
  New-AzSynapseRoleAssignment -ObjectId $UAMIIdentityID -RoleDefinitionId $roleId -WorkspaceName $SynapseWorkspaceName
  Write-Host "Role assignment created successfully."
}
else {
  Write-Host "Role assignment already exists. No action needed."
}

function Create-ManagedPrivateEndpoint {
  param (
    [string] $SynapseWorkspaceName,
    [string] $EndpointName,
    [string] $PrivateLinkResourceId,
    [string] $GroupId,
    [hashtable] $Headers,
    [int] $Retries = 10,
    [int] $SecondsDelay = 60
  )

  $uri = "https://$SynapseWorkspaceName.dev.azuresynapse.net/managedVirtualNetworks/default/managedPrivateEndpoints/$EndpointName"
  $uri += "?api-version=2019-06-01-preview"

  $body = @{
    name = "$EndpointName-$GroupId"
    type = "Microsoft.Synapse/workspaces/managedVirtualNetworks/managedPrivateEndpoints"
    properties = @{
      privateLinkResourceId = $PrivateLinkResourceId
      groupId = $GroupId
      name = $EndpointName
      fqdns = @("$EndpointName.private.outseer.com")
    }
  } | ConvertTo-Json -Depth 3

  Write-Host "Creating Managed Private Endpoint for $EndpointName..."
  $retryCount = 1
  $completed = $false

  while (-not $completed) {
    try {
      Invoke-RestMethod -Method Put -ContentType "application/json" -Uri $uri -Headers $Headers -Body $body -ErrorAction Stop
      Write-Host "Managed private endpoint for $EndpointName created successfully."
      $completed = $true
    }
    catch {
      if ($retryCount -ge $Retries) {
        Write-Host "Managed private endpoint for $EndpointName creation failed the maximum number of $retryCount times."
        throw
      }
      else {
        Write-Host "Managed private endpoint creation for $EndpointName failed $retryCount time(s). Retrying in $SecondsDelay seconds."
        Start-Sleep $SecondsDelay
        $retryCount++
      }
    }
  }
}

#------------------------------------------------------------------------------------------------------------
# CREATE MANAGED PRIVATE ENDPOINTS
#------------------------------------------------------------------------------------------------------------

# Process Private Link Endpoints
for ($i = 0; $i -lt $PrivateLinkNames.Length; $i++) {
  $endpointName = "$($PrivateLinkNames[$i])-pl"
  Create-ManagedPrivateEndpoint -SynapseWorkspaceName $SynapseWorkspaceName `
                                -EndpointName $endpointName `
                                -PrivateLinkResourceId $PrivateLinkIds[$i] `
                                -GroupId "pl" `
                                -Headers $headers
}

# Process SQL Private Endpoints
for ($i = 0; $i -lt $PrivateEndPointNames.Length; $i++) {
  $endpointName = "$($PrivateEndPointNames[$i])-sqlServer"
  Create-ManagedPrivateEndpoint -SynapseWorkspaceName $SynapseWorkspaceName `
                                -EndpointName $endpointName `
                                -PrivateLinkResourceId $PrivateEndPointIds[$i] `
                                -GroupId "sqlServer" `
                                -Headers $headers
}