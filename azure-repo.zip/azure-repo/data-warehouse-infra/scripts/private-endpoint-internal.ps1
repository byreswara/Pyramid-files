param(
  [Parameter(Mandatory=$true)]
  [string] $SynapseWorkspaceName,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakebbAccountName,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakebbAccountID,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakeAccountName,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakeAccountID,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakeTdsAccountName,
  [Parameter(Mandatory=$true)]
  [string] $WorkspaceDataLakeTdsAccountID,
  [Parameter(Mandatory=$true)]
  [string] $KeyVaultName,
  [Parameter(Mandatory=$true)]
  [string] $KeyVaultID,
  [Parameter(Mandatory=$true)]
  [string] $UAMIIdentityID
)

# now actually create things

$retries = 10
$secondsDelay = 60

#------------------------------------------------------------------------------------------------------------
# CONTROL PLANE OPERATION: ASSIGN SYNAPSE WORKSPACE ADMINISTRATOR TO USER-ASSIGNED MANAGED IDENTITY
# UAMI needs Synapse Admin rights before it can make calls to the Data Plane APIs to create Synapse objects
#------------------------------------------------------------------------------------------------------------

$token = (Get-AzAccessToken -Resource "https://dev.azuresynapse.net").Token
$headers = @{ Authorization = "Bearer $token" }

Write-Host "Assign Synapse Administrator Role to UAMI"

$roleId = "6e4bf58a-b8e1-4cc3-bbf9-d73143322b78"
$existingAssignment = Get-AzSynapseRoleAssignment -ObjectId $UAMIIdentityID -RoleDefinitionId $roleId -WorkspaceName $SynapseWorkspaceName -ErrorAction SilentlyContinue

if (-not $existingAssignment) {
  Write-Host "No existing role assignment found. Creating new role assignment..."
  New-AzSynapseRoleAssignment -ObjectId $UAMIIdentityID -RoleDefinitionId $roleId -WorkspaceName $SynapseWorkspaceName
  Write-Host "Role assignment created successfully."
}
else {
  Write-Host "Role assignment already exists. No action needed."
}

# now create internal private endpoints

[string[]] $managedPrivateEndpointNames = $KeyVaultName, $WorkspaceDataLakebbAccountName, $WorkspaceDataLakeAccountName, $WorkspaceDataLakeTdsAccountName
[string[]] $managedPrivateEndpointIDs = $KeyVaultID, $WorkspaceDataLakebbAccountID, $WorkspaceDataLakeAccountID, $WorkspaceDataLakeTdsAccountID
[string[]] $managedPrivateEndpointGroups = 'vault', 'dfs', 'dfs', 'dfs'

for($i = 0; $i -le ($managedPrivateEndpointNames.Length - 1); $i += 1)
{
  $managedPrivateEndpointName = [System.String]::Concat($managedPrivateEndpointNames[$i],"-",$managedPrivateEndpointGroups[$i])
  $managedPrivateEndpointID = $managedPrivateEndpointIDs[$i]
  $managedPrivateEndpointGroup = $managedPrivateEndpointGroups[$i] 

  $uri = "https://$SynapseWorkspaceName.dev.azuresynapse.net"
  $uri += "/managedVirtualNetworks/default/managedPrivateEndpoints/$managedPrivateEndpointName"
  $uri += "?api-version=2019-06-01-preview"

  $body = "{
      name: ""$managedPrivateEndpointName-$managedPrivateEndpointGroup"",
      type: ""Microsoft.Synapse/workspaces/managedVirtualNetworks/managedPrivateEndpoints"",
      properties: {
        privateLinkResourceId: ""$managedPrivateEndpointID"",
        groupId: ""$managedPrivateEndpointGroup"",
        name: ""$managedPrivateEndpointName""
      }
  }"

  Write-Host "Create Managed Private Endpoint for $managedPrivateEndpointName..."
  $retrycount = 1
  $completed = $false
  
  while (-not $completed) {
    try {
      Invoke-RestMethod -Method Put -ContentType "application/json" -Uri $uri -Headers $headers -Body $body -ErrorAction Stop
      Write-Host "Managed private endpoint for $managedPrivateEndpointName created successfully."
      $completed = $true
    }
    catch {
      if ($retrycount -ge $retries) {
        Write-Host "Managed private endpoint for $managedPrivateEndpointName creation failed the maximum number of $retryCount times."
        throw
      } else {
        Write-Host "Managed private endpoint creation for $managedPrivateEndpointName failed $retryCount time(s). Retrying in $secondsDelay seconds."
        Start-Sleep $secondsDelay
        $retrycount++
      }
    }
  }
}

#30 second delay interval for private link provisioning state = Succeeded
$secondsDelay = 30

#Approve Private Endpoints
for($i = 0; $i -le ($managedPrivateEndpointNames.Length - 1); $i += 1)
{
  $retrycount = 1
  $completed = $false
  
  while (-not $completed) {
    try {
      $managedPrivateEndpointName = [System.String]::Concat($managedPrivateEndpointNames[$i],"-",$managedPrivateEndpointGroups[$i])
      $managedPrivateEndpointID = $managedPrivateEndpointIDs[$i]
      # Approve KeyVault Private Endpoint
      $privateEndpoints = Get-AzPrivateEndpointConnection -PrivateLinkResourceId $managedPrivateEndpointID -ErrorAction Stop | where-object{$_.PrivateEndpoint.Id -match ($SynapseWorkspaceName + "." + $managedPrivateEndpointName)} | select-object Id, ProvisioningState, PrivateLinkServiceConnectionState
      
      foreach ($privateEndpoint in $privateEndpoints) {
        if ($privateEndpoint.ProvisioningState -eq "Succeeded") {
          if ($privateEndpoint.PrivateLinkServiceConnectionState.Status -eq "Pending") {
            Write-Host "Approving private endpoint for $managedPrivateEndpointName."
            Approve-AzPrivateEndpointConnection -ResourceId $privateEndpoint.Id -Description "Auto-Approved" -ErrorAction Stop    
            $completed = $true
          }
          elseif ($privateEndpoint.PrivateLinkServiceConnectionState.Status -eq "Approved") {
            $completed = $true
          }
        }
      }
      
      if(-not $completed) {
        throw "Private endpoint connection not yet provisioned."
      }
    }
    catch {
      if ($retrycount -ge $retries) {
        Write-Host "Private endpoint approval for $managedPrivateEndpointName has failed the maximum number of $retryCount times."
        throw
      } else {
        Write-Host "Private endpoint approval for $managedPrivateEndpointName has failed $retryCount time(s). Retrying in $secondsDelay seconds."
        Write-Warning $PSItem.ToString()
        Start-Sleep $secondsDelay
        $retrycount++
      }
    }
  }
}