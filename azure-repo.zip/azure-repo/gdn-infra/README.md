# Global Data Network infra

This repo contains the bicep template to deploy a GDN related resources to a target resource group. It contains the following resources - for now:
- Vnet
- Key Vault
- Synapse Workspace
- Storage Account

## Requirements
- A *new* resource group and an Azure devops service connection attached to the pipeline
- A configured Azure devops variable group with the following variables:
    - **azureResourceManagerConnection**: The name of the service connection
    - **location**: The region
    - **resourceGroupName**: The target resource group
    - **synapseAdminGroupObjectId**: The AAD id of the group which should have admin access in synapse
- The application user provisioned by Azure gitops needs to have RBAC permissions added to it (this is currently manual!)
- New deployments should be in branches named "/release/myname", with a corresponding variable group gdn-*myname* and bicep parameter file *myname.json*

## Known issues - copied from DWH readme
- Synapse connectivity is set to public by default, but with a firewall rule that blocks everything. An admin can add IPs to the firewall. Ultimately a private link setup will be used instead (via the VPN).
- Configuring synapse git integration is currently manual. Refer to the synapse data eng repo for instructions - ensure to follow naming and layout conventions